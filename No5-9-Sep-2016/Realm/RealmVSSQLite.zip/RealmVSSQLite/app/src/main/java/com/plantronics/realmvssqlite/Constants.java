package com.plantronics.realmvssqlite;

/**
 * Created by slobodan.pavic on 7/25/2016.
 */
public interface Constants {

    int NUMBER_OF_TEAMS = 100;
    int NUMBER_OF_EMPLOYEES_IN_TEAM = 1000;
}
