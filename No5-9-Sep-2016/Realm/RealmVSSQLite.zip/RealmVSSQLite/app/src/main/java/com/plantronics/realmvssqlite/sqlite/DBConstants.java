package com.plantronics.realmvssqlite.sqlite;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public interface DBConstants {

    String TEAM_TABLE = "teams";
    String EMPLOYEE_TABLE = "employees";
    String COLUMN_UID = "uid";

    String COLUMN_NAME = "name";
    String COLUMN_SURNAME = "surname";
    String COLUMN_AGE = "age";
    String COLUMN_FOREIGN_KEY = "team_id" ;

    String CREATE_TEAM_TABLE = "CREATE TABLE " + TEAM_TABLE  + " (" +
            COLUMN_UID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT" +
            ");";

    String CREATE_EMPLOYEE_TABLE = "CREATE TABLE " + EMPLOYEE_TABLE + " (" +
            COLUMN_UID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_NAME + " TEXT," +
            COLUMN_SURNAME + " INTEGER," +
            COLUMN_AGE + " DOUBLE," +
            COLUMN_FOREIGN_KEY + " TEXT," +

            "FOREIGN KEY (" + COLUMN_FOREIGN_KEY + ") REFERENCES " + TEAM_TABLE + "(" + COLUMN_UID + ")" +
            ");";
    String DROP_TEAM_TABLE = " DROP TABLE " + DBConstants.TEAM_TABLE + " IF EXISTS;";
    String DROP_EMPLOYEE_TABLE = " DROP TABLE " + DBConstants.EMPLOYEE_TABLE + " IF EXISTS;";


}
