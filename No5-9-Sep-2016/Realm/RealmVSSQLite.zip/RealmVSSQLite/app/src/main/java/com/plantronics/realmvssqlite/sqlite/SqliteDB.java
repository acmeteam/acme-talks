package com.plantronics.realmvssqlite.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Handler;
import android.util.Log;

import com.plantronics.realmvssqlite.Constants;
import com.plantronics.realmvssqlite.DurationCallback;
import com.plantronics.realmvssqlite.Repository;
import com.plantronics.realmvssqlite.Stopwatch;
import com.plantronics.realmvssqlite.models.Employee;
import com.plantronics.realmvssqlite.models.Team;

import java.util.List;
import java.util.concurrent.Executors;

import io.realm.RealmList;

/**
 * Created by {slobodan.pavic on 7/24/2016.]
 */
public class SqliteDB implements Repository {

    private DBHelper mDBHelper;
    private SQLiteDatabase mDatabase;
    private Handler mHandler;


    public SqliteDB(Context context, Handler handler) {
        mDBHelper = DBHelper.getInstance(context);
        mHandler = handler;
    }

    @Override
    public void addItems(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                mDatabase = mDBHelper.openDatabase();
                Team team = new Team(0, "Plantronics");
                RealmList<Employee> members = new RealmList<>();

                for (int i = 0; i < Constants.NUMBER_OF_EMPLOYEES_IN_TEAM; i++) {
                    Employee employee = new Employee(0, "Employee", "Empl", i);
                    members.add(employee);
                }
                team.setMembers(members);
                stopwatch.start();
                try {
                    String sql = "INSERT INTO " + DBConstants.TEAM_TABLE + " VALUES (?,?);";
                    //compile the statement and start a transaction
                    SQLiteStatement statement = mDatabase.compileStatement(sql);
                    mDatabase.beginTransaction();
                    statement.clearBindings();
                    String sql1 = "INSERT INTO " + DBConstants.EMPLOYEE_TABLE + " VALUES (?,?,?,?,?);";
                    //compile the statement and start a transaction
                    SQLiteStatement statement1 = mDatabase.compileStatement(sql1);
                    statement.clearBindings();
                    for (int i = 0; i < Constants.NUMBER_OF_TEAMS; i++) {
                        team.setId(i);
                        statement.bindLong(1, team.getId());
                        statement.bindString(2, team.getName());
                        addEmployees(team.getMembers(), statement1, team.getId());
                        statement.execute();
                    }

                    statement1.close();
                    statement.close();
                    mDatabase.setTransactionSuccessful();
                    mDatabase.endTransaction();
                    stopwatch.stop();
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            callback.onTransactionFinished(stopwatch.getDuration());

                        }
                    });

                } catch (SQLException sqlEx) {

                }
            }
        });
    }

    private void addEmployees(List<Employee> employees, SQLiteStatement statement, long foreignKey) {

        for (Employee item : employees) {
            statement.bindString(2, item.getName());
            statement.bindString(3, item.getSurname());
            statement.bindLong(4, (long) item.getAge());
            statement.bindLong(5, foreignKey);
            statement.execute();
        }
    }

    @Override
    public void readAllData(final DurationCallback callback) {

        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                RealmList<Team> teams = new RealmList<>();
                final Stopwatch stopwatch = new Stopwatch();
                stopwatch.start();
                String[] columns = new String[]{
                        DBConstants.COLUMN_UID,
                        DBConstants.COLUMN_NAME,
                };
                Cursor cursor = mDatabase.query(DBConstants.TEAM_TABLE, columns, null,
                        null, null, null, null);
                try {
                    if (cursor != null && cursor.moveToFirst()) {
                        do {
                            long id = cursor.getLong(cursor.getColumnIndex(DBConstants.COLUMN_UID));
                            String name = cursor.getString(cursor.getColumnIndex(DBConstants.COLUMN_NAME));
                            Team team = new Team(id, name);
                            team.setMembers(getTeamEmployees(id));
                            teams.add(team);

                        }
                        while (cursor.moveToNext());
                        cursor.close();
                        stopwatch.stop();
                        Log.d("TeamsSQLITE", teams.size() + "");
                        Log.d("TeamsSQLITE", teams.get(0).getMembers().get(0).getName());
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                callback.onTransactionFinished(stopwatch.getDuration());
                            }
                        });


                    }
                } catch (SQLException sql) {
                    sql.printStackTrace();
                }
            }
        });

    }

    private RealmList<Employee> getTeamEmployees(long teamID) {
        String[] columns = new String[]{
                DBConstants.COLUMN_UID,
                DBConstants.COLUMN_NAME,
                DBConstants.COLUMN_SURNAME,
                DBConstants.COLUMN_AGE,
                DBConstants.COLUMN_FOREIGN_KEY
        };
        RealmList<Employee> employees = new RealmList<>();
        Cursor cursor = mDatabase.query(DBConstants.EMPLOYEE_TABLE, columns, DBConstants.COLUMN_FOREIGN_KEY + "=" + teamID,
                null, null, null, null);

        try {
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    long id = cursor.getLong(cursor.getColumnIndex(DBConstants.COLUMN_UID));
                    String name = cursor.getString(cursor.getColumnIndex(DBConstants.COLUMN_NAME));
                    String surname = cursor.getString(cursor.getColumnIndex(DBConstants.COLUMN_SURNAME));
                    long age = cursor.getLong(cursor.getColumnIndex(DBConstants.COLUMN_AGE));

                    // add string test to list
                    Employee employee = new Employee(id, name, surname, age);
                    employees.add(employee);
                }
                while (cursor.moveToNext());
                cursor.close();

            }
        } catch (SQLException sql) {
            sql.printStackTrace();
        }

        return employees;
    }

    @Override
    public void deleteAllData(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                stopwatch.start();
                mDatabase = mDBHelper.openDatabase();
                mDatabase.beginTransaction();
                try {
                    Integer count = mDatabase.delete(DBConstants.TEAM_TABLE, null, null);
                    Integer count1 = mDatabase.delete(DBConstants.EMPLOYEE_TABLE, null, null);
                    Log.d("Rows deleted:", count.toString());
                    Log.d("Rows deleted:", count1.toString());

                    mDatabase.setTransactionSuccessful();
                    mDatabase.endTransaction();
                    stopwatch.stop();

                } catch (SQLException sql) {
                    sql.printStackTrace();
                } finally {
                    mDBHelper.closeDatabase();
                }


                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onTransactionFinished(stopwatch.getDuration());
                    }
                });
            }
        });
    }

    @Override
    public void update(final DurationCallback callback) {
     Executors.newSingleThreadExecutor().execute(new Runnable() {
         @Override
         public void run() {
             final Stopwatch stopwatch = new Stopwatch();

             String sql = "UPDATE employees SET name = 'Sony'";
             stopwatch.start();
             mDatabase.execSQL(sql);
             stopwatch.stop();
             readAllData(new DurationCallback() {
                 @Override
                 public void onTransactionFinished(double seconds) {

                 }
             });
             mHandler.post(new Runnable() {
                 @Override
                 public void run() {
                     callback.onTransactionFinished(stopwatch.getDuration());
                 }
             });

         }
     });
    }

    @Override
    public void count(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        Executors.newSingleThreadExecutor()
                .execute(new Runnable() {
            @Override
            public void run() {
                stopwatch.start();
                String sql = "SELECT COUNT(*) from employees";
                Cursor cursor = mDatabase.rawQuery(sql, null);
                cursor.moveToFirst();
                int count = cursor.getCount();
                cursor.close();
                stopwatch.stop();
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onTransactionFinished(stopwatch.getDuration());
                    }
                });
            }
        });

    }

    @Override
    public void sum(final DurationCallback callback) {
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                final Stopwatch stopwatch = new Stopwatch();
                String sql = "SELECT SUM(age) from employees";
                stopwatch.start();
                Cursor cursor = mDatabase.rawQuery(sql, null);
                cursor.moveToFirst();
                Double sum = cursor.getDouble(0);
                cursor.close();
                stopwatch.stop();
                Log.d("TeamsSQLITE", "SUM: " + sum.toString());
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onTransactionFinished(stopwatch.getDuration());
                    }
                });
            }
        });
    }

    @Override
    public void max(final DurationCallback callback) {
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                final Stopwatch stopwatch = new Stopwatch();
                String sql = "SELECT MAX(age) from employees";
                stopwatch.start();
                Cursor cursor = mDatabase.rawQuery(sql, null);
                cursor.moveToFirst();
                Double max = cursor.getDouble(0);
                cursor.close();
                stopwatch.stop();
                Log.d("TeamsSQLITE", "MAX: " + max.toString());
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onTransactionFinished(stopwatch.getDuration());
                    }
                });
            }
        });
    }

    @Override
    public void average(final DurationCallback callback) {
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                final Stopwatch stopwatch = new Stopwatch();
                String sql = "SELECT AVG(age) from employees";
                stopwatch.start();
                Cursor cursor = mDatabase.rawQuery(sql, null);
                cursor.moveToFirst();
                Double avg = cursor.getDouble(0);
                cursor.close();
                stopwatch.stop();
                Log.d("TeamsSQLITE", "AVG: " + avg.toString());
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        callback.onTransactionFinished(stopwatch.getDuration());
                    }
                });
            }
        });
    }

    @Override
    public void onDestroy() {
        mDBHelper.closeDatabase();
    }
}
