package com.plantronics.realmvssqlite.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public class DBHelper extends SQLiteOpenHelper {
    private static final int DB_VERSION = 1;
    private static final String DB_NAME = "headsets_db";
    private static DBHelper sInstance;
    private SQLiteDatabase mDatabase;
    private AtomicInteger mOpenCounter;

    public static synchronized DBHelper getInstance(Context context) {
        // Use the application context, which will ensure that you
        // don't accidentally leak an Activity's context.
        if (sInstance == null) {
            synchronized (DBHelper.class) {
                if (sInstance == null) {
                    sInstance = new DBHelper(context.getApplicationContext());
                }
            }
        }
        return sInstance;
    }

    public SQLiteDatabase openDatabase() {
        synchronized (this) {
            if (mOpenCounter.incrementAndGet() == 1) {
                mDatabase = getWritableDatabase();
            }
            return mDatabase;
        }
    }

    public void closeDatabase() {
        synchronized (this) {
            if (mOpenCounter.decrementAndGet() == 0) {
                mDatabase.close();
            }
        }
    }

    private DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        mOpenCounter = new AtomicInteger(0);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(DBConstants.CREATE_TEAM_TABLE);
        db.execSQL(DBConstants.CREATE_EMPLOYEE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            db.execSQL(DBConstants.DROP_TEAM_TABLE);
            db.execSQL(DBConstants.DROP_EMPLOYEE_TABLE);
            onCreate(db);

        } catch (SQLiteException exception) {
            exception.printStackTrace();
        }
    }
}
