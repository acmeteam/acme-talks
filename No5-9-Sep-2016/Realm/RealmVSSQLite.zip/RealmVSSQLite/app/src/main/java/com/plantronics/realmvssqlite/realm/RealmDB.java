package com.plantronics.realmvssqlite.realm;

import android.util.Log;

import com.plantronics.realmvssqlite.Constants;
import com.plantronics.realmvssqlite.DurationCallback;
import com.plantronics.realmvssqlite.Repository;
import com.plantronics.realmvssqlite.Stopwatch;
import com.plantronics.realmvssqlite.models.Employee;
import com.plantronics.realmvssqlite.models.Team;

import java.lang.reflect.Member;
import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.RealmResults;

/**
 * Created by {slobodan.pavic on 7/24/2016.}
 */
public class RealmDB implements Repository {

    private static final String TAG = RealmDB.class.getSimpleName();
    private Realm mRealm;

    public RealmDB() {
        mRealm = Realm.getDefaultInstance();
    }

    public void addItems(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();

        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                int index = 0;
                List<RealmObject> realmObjects = new ArrayList<>();
                for (int i = 0; i < Constants.NUMBER_OF_TEAMS; i++) {
                    Team team = new Team();
                    RealmList<Employee> employees = new RealmList<>();
                    team.setName("Plantronics");
                    team.setMembers(employees);
                    team.setId(i);
                    for (int j = 1; j < Constants.NUMBER_OF_EMPLOYEES_IN_TEAM; j++) {
                        Employee employee = new Employee(index + j, "employee", "empl", Math.random());
                        employees.add(employee);
                    }
                    realmObjects.add(team);
                    index = index + Constants.NUMBER_OF_EMPLOYEES_IN_TEAM - 1;
                }

                stopwatch.start();
                for (int i = 0; i < realmObjects.size(); i++) {
                    realm.copyToRealm(realmObjects.get(i));
                }
                stopwatch.stop();
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }


    public void readAllData(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                RealmResults<Team> teams = realm.where(Team.class)
                        .findAll();
                for (Team team : teams) {
                    for (Employee employee : team.getMembers()) {
                        employee.getAge();
                    }
                }
                stopwatch.stop();
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {

                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }

    public void deleteAllData(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                realm.deleteAll();
                stopwatch.stop();
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }

    public void update(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();

        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                RealmResults<Team> teams = realm
                        .where(Team.class)
                        .findAll();
                for (Team team : teams) {
                    team.setName("Sony");
                }
                stopwatch.stop();


            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });

        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                RealmResults<Team> teams = realm.where(Team.class).findAll();
                Log.d(TAG, "Team name: " + teams.get(76).getName());
            }
        });

    }

    public void count(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();

        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                RealmResults<Employee> employees = realm.where(Employee.class).findAll();
                stopwatch.stop();
                Log.d(TAG, "Number of employees: " + employees.size());
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }

    public void sum(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                RealmResults<Employee> employees = realm.where(Employee.class).findAll();
                Long sum = employees.sum("age").longValue();
                stopwatch.stop();
                Log.d(TAG, "Age sum: " + sum.toString());
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }

    public void max(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                RealmResults<Employee> employees = realm.where(Employee.class).findAll();
                Long max = employees.max("age").longValue();
                stopwatch.stop();
                Log.d(TAG, "Age max: " + max.toString());
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }

    public void average(final DurationCallback callback) {
        final Stopwatch stopwatch = new Stopwatch();
        mRealm.executeTransactionAsync(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                stopwatch.start();
                RealmResults<Employee> employees = realm.where(Employee.class).findAll();
                Double average = employees.average("age");
                stopwatch.stop();
                Log.d(TAG, "Age average: " + average.toString());
            }
        }, new Realm.Transaction.OnSuccess() {
            @Override
            public void onSuccess() {
                callback.onTransactionFinished(stopwatch.getDuration());
            }
        });
    }

    @Override
    public void onDestroy() {
        mRealm.close();
    }

}
