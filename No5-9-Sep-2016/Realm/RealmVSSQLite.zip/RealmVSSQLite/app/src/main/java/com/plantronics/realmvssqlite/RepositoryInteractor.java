package com.plantronics.realmvssqlite;

import com.plantronics.realmvssqlite.DurationCallback;
import com.plantronics.realmvssqlite.Repository;
import com.plantronics.realmvssqlite.Screen;

/**
 * Created by {slobodan.pavic on 7/24/2016.}
 */
public class RepositoryInteractor {

    private Repository mDatabase;
    private Screen mRealmScreen;

    public RepositoryInteractor(Screen screen, Repository database) {
        mDatabase = database;
        mRealmScreen = screen;
    }

    public void addTeams() {
        mDatabase.addItems(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onInsertFinished(seconds);
            }
        });
    }

    public void getTeams() {
        mDatabase.readAllData(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onQueryFinished(seconds);
            }
        });
    }


    public void deleteTeams() {
        mDatabase.deleteAllData(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onDeleteFinished(seconds);
            }
        });
    }

    public void updateTeams() {
        mDatabase.update(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onUpdateFinished(seconds);
            }
        });
    }

    public void countEmployees() {
        mDatabase.count(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onCountFinished(seconds);
            }
        });
    }

    public void sumEmployeesAges() {
        mDatabase.sum(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onSumFinished(seconds);
            }
        });
    }
    public void maxAgeEmployee() {
        mDatabase.max(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onMaxFinished(seconds);
            }
        });
    }

    public void averageAgeEmployees() {
        mDatabase.average(new DurationCallback() {
            @Override
            public void onTransactionFinished(double seconds) {
                mRealmScreen.onAverageFinished(seconds);
            }
        });
    }

    public void onDestroy() {
        mDatabase.onDestroy();
    }


}
