package com.plantronics.realmvssqlite;

/**
 * Created by slobodan.pavic on 7/25/2016.
 */
public interface Screen {

        void onInsertFinished(double seconds);

        void onQueryFinished(double seconds);

        void onDeleteFinished(double seconds);

        void onUpdateFinished(double seconds);

        void onCountFinished(double seconds);

        void onSumFinished(double seconds);

        void onMaxFinished(double seconds);

        void onAverageFinished(double seconds);



}
