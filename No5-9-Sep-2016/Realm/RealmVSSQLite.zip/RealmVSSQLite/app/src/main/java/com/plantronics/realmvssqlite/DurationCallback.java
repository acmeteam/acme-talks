package com.plantronics.realmvssqlite;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public interface DurationCallback {

    void onTransactionFinished(double seconds);
}
