package com.plantronics.realmvssqlite;

import android.util.Log;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public class Stopwatch {

    private long mStartTime;
    private long mDuration;
    public void start() {
        mStartTime = System.nanoTime();
    }

    public void stop() {
        mDuration = System.nanoTime() - mStartTime;
    }

    public double getDuration() {
        return  (double)mDuration / 1000000000.0;
    }
}
