package com.plantronics.realmvssqlite.ui;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.plantronics.realmvssqlite.R;
import com.plantronics.realmvssqlite.Screen;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(R.id.realm_fragment, ScreenFragment.newInstance(ScreenFragment.REALM));
        ft.add(R.id.sqlite_fragment, ScreenFragment.newInstance(ScreenFragment.SQLITE));
        ft.commit();
    }
}
