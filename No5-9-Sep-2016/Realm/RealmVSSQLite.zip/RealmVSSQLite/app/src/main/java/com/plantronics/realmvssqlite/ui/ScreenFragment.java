package com.plantronics.realmvssqlite.ui;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.plantronics.realmvssqlite.R;
import com.plantronics.realmvssqlite.realm.RealmDB;
import com.plantronics.realmvssqlite.RepositoryInteractor;
import com.plantronics.realmvssqlite.Screen;
import com.plantronics.realmvssqlite.sqlite.SqliteDB;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public class ScreenFragment extends Fragment implements Screen {

    private RepositoryInteractor mDBInteractor;
    public static final int REALM = 0;
    public static final int SQLITE = 1;
    public static final String FRAGMENT_TYPE = "com.plantronics.realmvssqlite.FRAGMENT_TYPE";

    public static ScreenFragment newInstance(int index) {
        ScreenFragment f = new ScreenFragment();
        Bundle args = new Bundle();
        args.putInt(FRAGMENT_TYPE, index);
        f.setArguments(args);
        f.setRetainInstance(true);
        return f;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.realm_fragment, container, false);

        int type = getArguments().getInt(FRAGMENT_TYPE);
        switch (type) {
            case REALM:
                mDBInteractor = new RepositoryInteractor(this, new RealmDB());
                ((TextView) view.findViewById(R.id.title)).setText(getString(R.string.realm_title));
                break;
            case SQLITE:
                mDBInteractor = new RepositoryInteractor(this, new SqliteDB(getActivity(), new Handler()));
                ((TextView) view.findViewById(R.id.title)).setText(getString(R.string.sqlite_title));
                break;
            default:
                break;
        }
        view.findViewById(R.id.start_query_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDBInteractor.addTeams();
            }
        });

        view.findViewById(R.id.delete_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDBInteractor.deleteTeams();
            }
        });
        return view;
    }

    @Override
    public void onInsertFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.adding_teams_duration);
        teamsView.setText(String.format("%s", "Insert: " + seconds));
        mDBInteractor.getTeams();
    }

    @Override
    public void onQueryFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.read_teams_duration);
        teamsView.setText(String.format("%s", "Read: " + seconds));
        mDBInteractor.updateTeams();
    }

    @Override
    public void onUpdateFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.update_teams_duration);
        teamsView.setText(String.format("%s", "Update: " + seconds));
        mDBInteractor.countEmployees();
    }

    @Override
    public void onCountFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.count_teams_duration);
        teamsView.setText(String.format("%s", "Count: " + seconds));
        mDBInteractor.sumEmployeesAges();
    }

    @Override
    public void onSumFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.sum_teams_duration);
        teamsView.setText(String.format("%s", "Sum: " + seconds));
        mDBInteractor.maxAgeEmployee();
    }

    @Override
    public void onMaxFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.max_teams_duration);
        teamsView.setText(String.format("%s", "Max: " + seconds));
        mDBInteractor.averageAgeEmployees();
    }

    @Override
    public void onAverageFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.average_teams_duration);
        teamsView.setText(String.format("%s", "Average: " + seconds));
    }

    @Override
    public void onDeleteFinished(double seconds) {
        TextView teamsView = (TextView) getView().findViewById(R.id.delete_teams_duration);
        teamsView.setText(String.format("%s", "Delete: " + seconds));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mDBInteractor.onDestroy();
    }
}
