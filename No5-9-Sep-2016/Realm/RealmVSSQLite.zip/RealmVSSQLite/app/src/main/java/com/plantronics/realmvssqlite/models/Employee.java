package com.plantronics.realmvssqlite.models;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public class Employee extends RealmObject {

    private long id;
    private String name;
    private String surname;
    private double age;

    public Employee() {

    }

    public Employee(long id, String name, String surname, double age) {
        this.id = id;
        this.age = age;
        this.name = name;
        this.surname = surname;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public double getAge() {
        return age;
    }

    public void setAge(double age) {
        this.age = age;
    }
}
