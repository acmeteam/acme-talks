package com.plantronics.realmvssqlite.models;

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by slobodan.pavic on 7/24/2016.
 */
public class Team extends RealmObject {

    private long id;
    private String name;
    private RealmList<Employee> members;

    public Team() {

    }
    public Team(long id, String name) {
        this.id = id;
        this.name = name;
        this.members = new RealmList<>();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public RealmList<Employee> getMembers() {
        return members;
    }

    public void setMembers(RealmList<Employee> members) {
        this.members = members;
    }
}
