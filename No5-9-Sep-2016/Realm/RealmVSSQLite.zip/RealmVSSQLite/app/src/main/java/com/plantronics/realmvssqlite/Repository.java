package com.plantronics.realmvssqlite;

/**
 * Created by {slobodan.pavic on 7/30/2016.}
 */
public interface Repository {

    void addItems(DurationCallback callback);

    void readAllData(final DurationCallback callback);

    void deleteAllData(final DurationCallback callback);

    void update(final DurationCallback callback);

    void count(final DurationCallback callback);

    void sum(final DurationCallback callback);

    void max(final DurationCallback callback);

    void average(final DurationCallback callback);

    void onDestroy();
}
